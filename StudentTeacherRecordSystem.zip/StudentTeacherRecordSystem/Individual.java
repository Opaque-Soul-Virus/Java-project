package StudentTeacherRecordSystem;

public abstract class Individual {
    //atributes
    protected String name;
    protected String id;

    //constructor
    public Individual(String name, String id) {
        this.name = name;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    public abstract String getDetails();
}
