package StudentTeacherRecordSystem;

public class TeacherGUI {
}
