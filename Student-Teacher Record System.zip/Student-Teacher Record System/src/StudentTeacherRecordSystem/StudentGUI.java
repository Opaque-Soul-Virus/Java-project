package StudentTeacherRecordSystem;

import javax.swing.*;

public class StudentGUI extends JFrame {
    private JLabel nameLevel = new JLabel("Student Name :");
    private JLabel idLevel = new JLabel("Student ID :");
    private JLabel gradesLevel = new JLabel("Grades[5] :");
    private JTextField tfName = new JTextField();
    private JTextField tfId = new JTextField();
    private JTextField tfGrades = new JTextField();
    private JButton addButton = new JButton("Add Button");
    private JButton viewRecords = new JButton("View Records");
    //constructor
    public StudentGUI(){
        setTitle("Add Student Records ");
        setSize(400,600);
    }
}
