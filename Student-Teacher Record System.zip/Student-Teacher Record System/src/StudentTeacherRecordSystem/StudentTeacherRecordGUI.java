package StudentTeacherRecordSystem;

import java.awt.*;

public class StudentTeacherRecordGUI extends Frame {

}
