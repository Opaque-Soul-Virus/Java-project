package StudentTeacherRecordSystem;

import java.util.ArrayList;

public class StudentTeacherRecordSystem {
    private ArrayList<Student> students;
    private ArrayList<Teacher> teachers;

    //constructor
    public StudentTeacherRecordSystem() {
        this.students = new ArrayList<Student>();
        this.teachers = new ArrayList<Teacher>();
    }

    //Student and Teacher record store in ArrayList
    public void addStudent(Student student){
        this.students.add(student);
    }
    public void addTeacher(Teacher teacher){
        this.teachers.add(teacher);
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public ArrayList<Teacher> getTeachers() {
        return teachers;
    }

    //for showing output
    public void displayRecords(int choise){
        if(choise == 1) {
            System.out.println("Students : ");
            for (Student student : students) {
                System.out.println(student.getDetails());
            }
        }else if(choise == 2) {
            System.out.println("Teacher");
            for (Teacher teacher:teachers){
                System.out.println(teacher.getDetails());
            }
        }
    }
}
